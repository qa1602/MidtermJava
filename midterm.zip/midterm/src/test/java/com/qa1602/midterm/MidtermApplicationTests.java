package com.qa1602.midterm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MidtermApplicationTests {

	@Test
	void contextLoads() {
	}

}
